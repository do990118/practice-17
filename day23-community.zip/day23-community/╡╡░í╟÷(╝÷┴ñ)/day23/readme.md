# 피그마 파일 
https://www.figma.com/file/y5WCOezVdkt89CZC7DYjAw/COMMUNITY/duplicate

# 이미지와 텍스트 정보는 피그마에서 직접 뽑아서 사용 
